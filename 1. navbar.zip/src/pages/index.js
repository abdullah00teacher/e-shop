export {default as  Contact} from "./contact/Contact"
export {default as Home } from "./home/Home"