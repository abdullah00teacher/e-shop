import React from 'react'
import styles from "./contact.module.scss"

const Contact = () => {
  return (
    <div>Contact</div>
  )
}

export default Contact