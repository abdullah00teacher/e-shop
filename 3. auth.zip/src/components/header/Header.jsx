import React, { useState } from 'react'
import styles from "./header.module.scss"
import { Link, NavLink } from 'react-router-dom'
import { FaShoppingCart } from "react-icons/fa"
import { HiOutlineMenuAlt3 } from 'react-icons/hi'
import { FaTimes } from 'react-icons/fa'



const logo = (
    <div className={styles.logo}>
        <NavLink to={'/'}>
            <h2>e<span>Shop</span>.</h2>
        </NavLink>
    </div>
)

const cart = (
    <span className={styles.cart}>
        <NavLink to={'/cart'}>
            Cart
            <FaShoppingCart size={20} />
            <p>0</p>
        </NavLink>
    </span>
)

const Header = () => {

    const [showMenu, setShowMenu] = useState(false)

    const activeLink = ({isActive}) => (isActive ? `${styles.active}` : "")

    const toggleMenu = () => {
        setShowMenu(!showMenu)
    }


    const hideMenu = () => {
        setShowMenu(false)
    }

    return (
        <header>
            <div className={styles.header}>
                {logo}

                <nav className={showMenu ? `${styles["show-nav"]}` : `${styles["hide-nav"]}`} onClick={hideMenu}>
                    <div className={showMenu ? `${styles['nav-wrapper']} ${styles["show-nav-wrapper"]}` : `${styles["nav-wrapper"]}`}></div>
                    <ul>
                        <li className={styles["logo-mobile"]}>
                           {logo}
                           <FaTimes size={22} color='#fff'/>
                        </li>
                        <li>
                            <NavLink to={'/'} className={activeLink}>Home</NavLink>
                        </li>
                        <li>
                            <NavLink to={'/contact'} className={activeLink}>Contact Us</NavLink>
                        </li>
                    </ul>
                    <div className={styles['header-right']} onClick={toggleMenu}>
                        <span className={styles.links}>
                            <NavLink to={'/login'} className={activeLink}>Login</NavLink>
                            <NavLink to={'/register'} className={activeLink}>Register</NavLink>
                            <NavLink to={'/order-history'} className={activeLink}>My Orders</NavLink>
                        </span>
                        {cart}
                    </div>
                </nav>


                <div className={styles['menu-icon']}>
                   {!showMenu ?  <HiOutlineMenuAlt3 size={28} onClick={toggleMenu}/>  : ""}
                </div>
            </div>
        </header>
    )
}

export default Header