import React from 'react'
import Card from '../../components/card/Card'
import { Link } from 'react-router-dom'
import styles from "./auth.module.scss"
import registerImg from "../../assets/register.png"

const Register = () => {
    return (
        <section className={`container ${styles.auth}`}>


            <Card>
                <div className={styles.form}>

                    <h2>Register</h2>
                    <form>
                        <input type="text" placeholder='Email' required />
                        <input type="password" placeholder='Password' required />
                        <input type="password" placeholder='Confirm Password' required />
                        <button className='--btn --btn-primary --btn-block'>Login</button>
                        <div className={styles.links}>
                        </div>
                        <p>-- or --</p>
                    </form>
                    <span className={styles.register}>
                        <p>Do you have an account?</p>
                        <Link to={'/login'}>Login</Link>
                    </span>
                </div>
            </Card>
            <div className={styles['img-register']}>
                <img src={registerImg} alt="Login" width="280px"  />
            </div>
        </section>
    )
}

export default Register