import React from 'react'
import Card from '../../components/card/Card'
import { Link } from 'react-router-dom'
import styles from "./auth.module.scss"
import resetImg from "../../assets/reset.jpg"

const Reset = () => {
    return (
        <section className={`container ${styles.auth}`}>
            <div className={styles.img}>
                <img src={resetImg} alt="reset password" width="280px" height={'200px'} />
            </div>

            <Card>
                <div className={styles.form}>

                    <h2>Reset Password</h2>
                    <form>
                        <input type="email" placeholder='Reset Password' required />
                        <button className='--btn --btn-primary --btn-block'>Login</button>
                        <div className={styles.links}>
                        <p><Link to={'/login'}>Login</Link></p>
                        <p><Link to={'/login'}>Register</Link></p>
                        </div>
                    </form>
                </div>
            </Card>

        </section>
    )
}

export default Reset